
var ajaxUrl = "https://www.hljzsc.top/goldPig";
// var ajaxUrl="http://192.168.124.12"



function anim() {
    // $("#imgdonghua").remove(".bi")
    console.log("dianji")
    $("#bi1").animate({
        top: '190px',
    }, 1000);
    $("#bi1").fadeOut()
    $("#bi1").animate({
        top: '-10%',
    }, 1);
    $("#bi2").fadeIn()

    $("#bi2").animate({
        top: '190px',
    }, 1500);
    $("#bi2").fadeOut()
    $("#bi2").animate({
        top: '-20%',
    }, 1);
    $("#bi2").fadeIn()

    $("#bi3").animate({
        top: '190px',
    }, 800);
    $("#bi3").fadeOut()
    $("#bi3").animate({
        top: '-5%',
    }, 1);
    $("#bi3").fadeIn()

    $("#bi4").animate({
        top: '190px',
    }, 1300);
    $("#bi4").fadeOut()
    $("#bi4").animate({
        top: '-10%',
    }, 1);
    $("#bi4").fadeIn()

    $("#bi5").animate({
        top: '190px',
    }, 1000);
    $("#bi5").fadeOut()
    $("#bi5").animate({
        top: '-5%',
    }, 1);
    $("#bi5").fadeIn()

}

function jifenPage(){
    var url="/goldPig/share/showShare"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
           console.log(json)
            $("#leizhu").html(json.retData.goldPigNum) 
            $("#yaoqingma").html(json.retData.shareNum) 
            $("#okman").html(json.retData.personNum) 
            $("#mypig").html(json.retData.myGoldPig) 
            $("#mycoin").html(json.retData.myGoldCoin) 
            $("#cointime").html(json.retData.myGoldPig) 

        }

    })
}