
var ajaxUrl = "https://www.hljzsc.top/goldPig";

// var ajaxUrl = "http://192.168.124.12:8085";

function getUser() {      //获取用户信息
    var url = "/goldPig/customer/getCustomer"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var aa = json.retData
            console.log(aa)
            $(".userImg").attr("src", "../" + aa.img)
            $(".userC_name").html(aa.userName)
            if (json.retData.customerLevel == 1) {
                $("#userVip").css("display", "block")
            }
        }
    })
}

function userInfo() {
    var url = "/goldPig/customer/getCustomer"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            var aa = json.retData

            if (aa != null) {
                $(".accountImg").attr("src", "../" + aa.img)
                $(".accountTxt1").html(aa.userName)
                $(".accountTxt2").html(aa.phone)
            }
        }
    })
}


function gaiming() {
    var url = "/goldPig/customer/changeCustomer"

    aa = $("#userName").val()
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "userName=" + aa,
        "dataType": "json",
        "success": function (json) {

            console.log(aa)
            location.href = "user.html"
        }
    })
}
function uploadImage() {          //改头像2
    //判断是否有选择上传文件
    var imgPath = $("#input_file").val();
    if (imgPath == "") {
        alert("请选择图片文件！");
        return;
    }
    //判断上传文件的后缀名
    var strExtension = imgPath.substr(imgPath.lastIndexOf('.') + 1);
    if (strExtension != 'jpg' && strExtension != 'png') {
        alert("请选择图片文件");
        return;
    }
    var file = new FormData(document.getElementById("form2"));
    var files = $('#input_file')[0].files[0];
    var size = files.size;
    if (size > 5500000) {
        alert("图片大小不能超过5m")
    }
    else {
        $.ajax({
            xhrFields: { withCredentials: true },
            type: "POST",
            url: "https://www.hljzsc.top/goldPig/goldPig/customer/uploadImg",
            data: file,
            datatype: 'json',
            processData: false,
            contentType: false,

            success: function (data) {
                location.href = "accountManagement.html"

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

                return false;
            }
        });
    }

}



//待发货
function daifahuo() {
    var url = "/goldPig/customer/showMyOrder"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            $("#cartCenter").empty()
            console.log(json)
            var dingdan = json.retData.listData
            for (var i = 0; i < dingdan.length; i++) {
                var html =
                    '<div class="cartsItem">'
                    + '<div class="CartDelete">商家未发货</div>'
                    + '<div class="cartsItemCenter">'
                    + '<img class="goodsImg" src="{#goodsImg}">'
                    + '<div class="cartItemCright">'
                    + '<div class="goodsName">{#goodsName}</div>'

                    + '<div class="goodsPrice">￥{#money}</div>'
                    + '<input type="button" class="cuiBtn" value="催发货">'
                    + '</div></div></div>'

                html = html.replace("{#goodsImg}", dingdan[i].image)
                html = html.replace("{#goodsName}", dingdan[i].goodsName)

                html = html.replace("{#money}", dingdan[i].paymentMoney)

                if (dingdan[i].orderStatus == 2) {
                    $("#cartCenter").append(html)
                }
            }
        }
    })
}

function indent() {
    var url = "/goldPig/customer/showMyOrder"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var dingdan = json.retData.listData
            $("#userIndentCenter").empty()

            for (var i = 0; i < dingdan.length; i++) {
                var html =

                    '<div class="buyShopIndent">'
                    + '<div class="shopIndentTop">'
                    + '<img class="shopIndenImg" src="../images/zhu.png">'
                    + '<div class="shopIndentItem">欢乐金猪商城</div>'
                    + '<div class="indentState">{#zhuangtai}</div></div>'
                    + '<div class="buySome">'
                    + '<div class="indentCouponName">{#goodsName}</div>'
                    + '<div class="indentCouponCount">×1</div></div>'
                    + '<div class="indentnowPay">{#money}元</div>'
                    + '<div class="couponBtn">'
                    + '<div class="indentTime">{#time}</div></div>'




                html = html.replace("{#goodsImg}", dingdan[i].image)
                html = html.replace("{#goodsName}", dingdan[i].goodsName)
                html = html.replace("{#money}", dingdan[i].paymentMoney)
                html = html.replace("{#time}", dingdan[i].createTime)
                if (dingdan[i].orderStatus == 2) {
                    html = html.replace("{#zhuangtai}", "订单未发货")
                    $("#userIndentCenter").append(html)
                }
                else if (dingdan[i].orderStatus == 3) {
                    html = html.replace("{#zhuangtai}", "订单已完成")
                    $("#userIndentCenter").append(html)
                }
              
            }



        }
    })
}












//提现

function dangqianketi() {      //当前可提
    var url = "/goldPig/customer/getCustomer"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            $("#ketixian").html(json.retData.saveMoney)
        }
    })
}
function tixianCard() {
    var url = "/goldPig/customerB/getB"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            $("#userZhangHao").html(json.retData.bankcard)

        }
    })
}
function tixian() {           //提现
    var url = "/goldPig/customerB/withdrawMoney"
    var money = $("#tixianNumTxt").val()
    console.log(money)
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "money=" + money,
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            alert(json.retMsg)


        }


    })
}

function yitixian() {
    var url = "/goldPig/customerB/showWithdrawReport"
    var money = $("#tixianNumTxt").val()
    console.log(money)
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "money=" + money,
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var tixaindan = json.retData.listData
            for (var i = 0; i < tixaindan.length; i++) {
                var html =
                    '<div class="tixianItem">'
                    + '<div class="tixianUser">{#userName}</div>'
                    + '<div class="tixianMoney">提现金额：{#money}元</div>'
                    + '<div class="tixainPhone">提现账号：{#userphone}</div>'
                    + '<div class="tixiantime">已完成</div></div>'

                html = html.replace("{#userName}", tixaindan[i].userName)
                html = html.replace("{#money}", tixaindan[i].withdraw)
                html = html.replace("{#userphone}", tixaindan[i].bankcard)
                // html = html.replace("{#time}", tixaindan[i].createTime)

                $("#tixianClass").append(html)
            }

        }


    })
}

//收款地址

function showMoney() {     //展示

    console.log("aa")
    var url = "/goldPig/customerB/getB"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            if (json.retData == null) {
                $("#dizhiClass").empty()
            }
            console.log(json)
            $(".userName").html(json.retData.handlerName)

            $(".dizhiCenter").html("账号：" + json.retData.bankcard)
        }
    })
}
function addInfo() {     //修改已有
    var url = "/goldPig/customerB/getB"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            $("#userName").val(json.retData.handlerName)
            $("#userPhone").val(json.retData.bankcard)
            $("#userSite").val(json.retData.remark)
        }
    })
}
function addMoney() {       //修改
    var mingzi = $("#userName").val()
    var zhifuhao = $("#userPhone").val()
    var beizhu = $("#userSite").val()
    var url = "/goldPig/customerB/addB"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "bankcard=" + zhifuhao + "&remark=" + beizhu + "&handlerName=" + mingzi,
        "dataType": "json",
        "success": function (json) {
            console.log("Aaa")
            console.log(json)
            location.href = "userGather.html"
        }
    })
}


//地址
function showSite() {
    var url = "/goldPig/address/showAddress"


    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var aa = json.retData.listData

            $("#dizhiClass").empty();
            for (var i = 0; i < aa.length; i++) {
                var html =

                    '<div class="dizhiItem">'
                    + '<div class="dizhiTop">'
                    + '<div class="userName">#{userName}</div>'
                    + '<div class="userPhone">#{phone}</div></div>'
                    + '<div class="dizhiCenter">#{userSite}</div>'
                    + '<div class="dizhiBottom">'
                    // + '<input class="sheweimoren" id="moren{#siteid}" type="button" value="设为默认"onclick="morendeSite({#siteid})">'
                    + '<input class="dizhiEditor" type="button" value="编辑" onclick="editorSite({#siteid})">'
                    + '<input class="dizhiDelete" type="button" value="删除"onclick="deleteSite({#siteid})">'

                    + '</div>'
                    + '</div>'

                var id = new RegExp("{#siteid}", "g")
                html = html.replace(id, aa[i].id);
                html = html.replace("#{userName}", aa[i].userName);
                html = html.replace("#{phone}", aa[i].phone);
                html = html.replace("#{userSite}", aa[i].address);

                $("#dizhiClass").append(html);

            }

        }
    })
}
function editorSite(id) {              //修改地址
    location.href = "addSite.html?" + id

}
function addSite() {             //增加地址
    location.href = "addSite.html"
}
function deleteSite(id) {           //删除地址
    var url = "/goldPig/address/delAddress"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "id=" + id,
        "dataType": "json",
        "success": function (json) {
            location.href = "userSite.html"
        }
    })
}

function sitePage(id) {
    var url = "/goldPig/address/addressDetails"
    if (id != "" || null) {

        $.ajax({
            "xhrFields": {
                withCredentials: true
            },
            "url": ajaxUrl + url,
            "type": "post",
            "data": "id=" + id,
            "dataType": "json",
            "success": function (json) {
                console.log(json)
                var yonghuInfo = json.retData
                $("#userName").val(yonghuInfo.userName)
                $("#userPhone").val(yonghuInfo.phone)
                $("#userSite").val(yonghuInfo.address)
            }
        })
    }
}
function submitSite() {
    var aaa = location.search.substring(1)
    console.log("aaa ")
    var url = "/goldPig/address/addAddress"
    var mingzi = $("#userName").val()
    var dizhi = $("#userSite").val()
    var phone = $("#userPhone").val()
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "address=" + dizhi + "&phone=" + phone + "&id=" + aaa + "&name=" + mingzi,
        "dataType": "json",
        "success": function (json) {
            alert("保存成功！")
            location.href = "userSite.html"
        }
    })
}

function morendeSite(id) {
    console.log(id)
    var url = "/goldPig/address/setDefault"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "id=" + id,
        "dataType": "json",
        "success": function (json) {
            $("#moren" + id).css("background-color", "red")
        }
    })


}

function opinion() {

    var url = "/goldPig/customer/addComplain"

    aa = $("#userOpinionTxt").val()
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "complainText=" + aa,
        "dataType": "json",
        "success": function (json) {
            alert("发送成功，我们会在24小时内联系您，请保持电话畅通！")

        },
        "fail": function () {
            alert("有点问题，请稍后重试！")
        }
    })
}


function tijiaocode() {
    var url = "/goldPig/customer/foreRegist"
    var code = $("#shuruma").val()
    var pattern = /\d{4}$/;
    if (!pattern.exec(code)) {
        alert("请输入正确的邀请码！aaa")
        return
    }
    else {
        $.ajax({
            "xhrFields": {
                withCredentials: true
            },
            "url": ajaxUrl + url,
            "type": "post",
            "data": "shareNum=" + code,
            "dataType": "json",
            "success": function (json) {

                alert(json.retMsg)
                $("#inputCode").css("display", "none")
            }
        })
    }

}

function guanbi() {
    $("#inputCode").fadeOut()
}

