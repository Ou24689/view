var ajaxUrl = "https://www.hljzsc.top/goldPig";

// var ajaxUrl = "http://192.168.124.12";


function shopClick(a){            //商品分类
    location.href="templates/shopClass.html?"+a
}
function shopClick2(a){
    location.href="shopClass.html?"+a
}



function lunbo() {
    var url = "/goldPig/slideshow"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var tupian = json.retData.listData
            $("#lunbo1").attr("src",tupian[0].img)
            $("#lunbo2").attr("src", tupian[1].img)
            $("#lunbo3").attr("src", tupian[2].img)
        }
    })
}





function indexgoods() {      //主页加载商品
    var url = "/goldPig/store/showGoods"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var maxPage = json.retData.listData
            $("#commodity").empty()
            for (var i = 0; i < maxPage.length; i++) {
                var html =
                    '<div class="commItem"onclick="goodsId({#itemid})">'
                +'<div class="CIleft">'
                +'<img class="commImg" src="{#goodsImg}"></div>'
                +'<div class="CIright">'
                +'<div class="commName">{#goodsName}</div>'
                +'<div class="commPrice">￥{#goodsPrice}</div>'
                +'<div class="commHint">'
                +'<div class="commNum">{#xiaoshou}月销售</div>'
                +'<div class="commpig">赠{#zhu}只金猪</div>'
                +'</div></div></div>'

                var item = new RegExp("{#itemid}", "g")
                html = html.replace(item, maxPage[i].goodsId)
                html = html.replace("{#goodsImg}", maxPage[i].img)
                html = html.replace("{#goodsName}", maxPage[i].goodsName)
                html = html.replace("{#goodsPrice}", maxPage[i].prices)
                html = html.replace("{#xiaoshou}", maxPage[i].soldNum)
                html = html.replace("{#zhu}", maxPage[i].goldPig)

                $("#commodity").append(html);
            }


        }
    })
}

function fenleiPage(id){
    var url = "/goldPig/store/showGoods"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data":"type="+id,
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var maxPage = json.retData.listData
            $("#commodity").empty()
            for (var i = 0; i < maxPage.length; i++) {
                var html =
                '<div class="commItem"onclick="goodsId2({#itemid})">'
                +'<div class="CIleft">'
                +'<img class="commImg" src="../{#goodsImg}"></div>'
                +'<div class="CIright">'
                +'<div class="commName">{#goodsName}</div>'
                +'<div class="commPrice">￥{#goodsPrice}</div>'
                +'<div class="commHint">'
                +'<div class="commNum">{#xiaoshou}月销售</div>'
                +'<div class="commpig">赠{#zhu}只金猪</div>'
                +'</div></div></div>'

                var item = new RegExp("{#itemid}", "g")
                html = html.replace(item, maxPage[i].goodsId)
                html = html.replace("{#goodsImg}", maxPage[i].img)
                html = html.replace("{#goodsName}", maxPage[i].goodsName)
                html = html.replace("{#goodsPrice}", maxPage[i].prices)
                html = html.replace("{#xiaoshou}", maxPage[i].soldNum)
                html = html.replace("{#zhu}", maxPage[i].goldPig)

                $("#commodity").append(html);
            }

            $("#" + id).addClass("commodityItem_active")
            $("#" + id).siblings().removeClass('commodityItem_active');

        }
    })
}


function goodsId(id){
location.href="templates/shopItem.html?"+id 
}
function goodsId2(id){
    location.href="shopItem.html?"+id 
    }
function goodsPage(id){
    var url = "/goldPig/store/goodsDetails";
    $.ajax({
        "url": ajaxUrl + url,
        "type": "post",
        "data": "id=" + id,
        "dataType": "json",

        "success": function (json) {

            var maxPage = json.retData.listData

            console.log(maxPage);
            console.log(json)
var img=String(maxPage[0].imgMore).split(";")
$("#img1").attr("src", "../"+img[1])
$("#img2").attr("src", "../"+img[2])
$("#img3").attr("src", "../"+img[3])
$("#shopItemCenter").empty();
var html =

    '<div class="shopItemCareless">'
    + ' <div class="shopItemName">'
    + '<div class="shopItemTheme">{#goodsName}</div>'
    + '<div class="shopItemPraise">{#goodsDetail}</div>'
    + '</div>'

    + '<div class="SIsell">'
    + '<div class="SInowprice" >￥{#nowPrice}</div>'
    + '<s class="SIoverprice">￥{#oldPrice}</s>'
    + '<div class="SIsellTxt">已售</div>'
    + '<div class="SIsellCount">{#xiaoliang}</div>'
    + '</div>'
    + '</div>'
    + '</div>'

html = html.replace("#{img}", maxPage[0].img);
html = html.replace("{#goodsName}", maxPage[0].goodsName);
html = html.replace("{#goodsDetail}", maxPage[0].title);
html = html.replace("{#nowPrice}", maxPage[0].prices);
html = html.replace("{#oldPrice}", maxPage[0].oldPrice);
html = html.replace("{#xiaoliang}", maxPage[0].soldNum);

$("#shopItemCenter").append(html);
$(".shopMerchant").html(maxPage[0].goldPig+"只")
$("#shopItemDetails").empty()
var xiangqingtu=maxPage[0].imgMore.split(";")
console.log(xiangqingtu)
for(var t=1;t<xiangqingtu.length;t++){
    var detail=

'<img  class="SIDimg" src="../{#imga}" alt="">'
detail=detail.replace("{#imga}",xiangqingtu[t])
$("#shopItemDetails").append(detail)
}

        }
    })
}



function jiaruCart(id) {

    var url = "/goldPig/cart/addToCart"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "goodsId=" + id,
        "dataType": "json",
        "success": function (json) {
            alert("加入成功！")
            console.log(json)

        }

    })
}



function chuanKey(key) {

    var url = "/goldPig/wx/sendkey"
    $.ajax({
        "url": ajaxUrl + url,
        "type": "post",
        "data": "key=" + key,
        "dataType": "json",

        "success": function (json) {
        }
    })
}



function panduan(){
    var url="/goldPig/share/getShareState"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
console.log(json)

if(json.retCode==206){
    $("#inputCode").css("display","none")
}
        }
    })
}

