var ajaxUrl = "https://www.hljzsc.top/goldPig";
// var ajaxUrl = "http://192.168.124.12";







function morenSite() {    //用户地址
    var url = "/goldPig/address/showAddress"


    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var aaa = json.retData.listData

          


            for (var i = 0; i < aaa.length; i++) {
                if (aaa[i].status == 1) {

                    $(".userName").html(aaa[i].userName)
                    $(".userPhone").html(aaa[i].phone)
                    $(".dizhiCenter").html(aaa[i].address)
                    $("#dizhiid").val(aaa[i].id)
                  
                    
                }
               

            }
        }
    })
}







function buyPage(id) {
  
    var url = "/goldPig/store/goodsDetails";
    $.ajax({
        "url": ajaxUrl + url,
        "type": "post",
        "data": "id=" + id,
        "dataType": "json",

        "success": function (json) {
            var goods = json.retData.listData[0]
            console.log(json)
            $("#goodsImg").attr("src", "../"+goods.img)
            $("#goodsName").html(goods.goodsName)
            $("#goodsPrice").html(goods.prices)
            total()
        }
    })
}






function payOrder(goodsId, goodsNum, money) {
    var url = "/goldPig/order/createOrder"
    var dizhiid = $("#dizhiid").val()
    if( $("#dizhiid").val()=="a"){
        alert("请先填写地址")
        location.href="userSite.html"
       }
    var aaa = goodsId + "" + goodsNum + 0 + money
    console.log(aaa)
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "goodsId=" + goodsId + "&num=" + goodsNum + "&discount=" + 0 + "&money=" + money + "&encodeStr=" + aaa + "&addressId=" + dizhiid,
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var _appId = json.retData.appId
            var _nonceStr = json.retData.nonceStr
            var _prepayid = json.retData.package
            var prepayId = _prepayid.substring(10)
            var _paySign = json.retData.paySign
            var _timestamp = json.retData.timeStamp;

            wx.config({

                //debug: true,
                appId: _appId, // 必填，公众号的唯一标识
                timestamp: "" + _timestamp, // 必填，生成签名的时间戳
                nonceStr: _nonceStr, // 必填，生成签名的随机串
                signType: "MD5",
                paySign: _paySign,// 必填，签名
                jsApiList: ['chooseWXPay', 'requestPayment'] // 必填，需要使用的JS接口列表

            });
            wx.ready(function () {
                // location.href="userCoupon.html"
               wx.miniProgram.navigateTo({ url: '/pages/WXpay/WXpay?' + "aaaa=" + _appId + "&bbbb=" + _timestamp + "&cccc=" + _nonceStr + "&dddd=" + prepayId + "&eeee=" + _paySign });
            });
            wx.error(function () {

            });



        }
    })
}








