var ajaxUrl = "https://www.hljzsc.top/goldPig";
//  var ajaxUrl = "http://192.168.124.12";

function toMoney(num) {
    num = parseFloat(num)
    num = num.toLocaleString();
    return num;//返回的是字符串23,245.12保留2位小数
}
function morenSite() {
    var url = "/goldPig/address/showAddress"


    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            var aaa = json.retData.listData
            for (var i = 0; i < aaa.length; i++) {
                if (aaa[i].status == 1) {

                    $(".userName").html(aaa[i].userName)
                    $(".userPhone").html(aaa[i].phone)
                    $(".dizhiCenter").html(aaa[i].address)
                    var aaaa=
                    '<input id="dizhiid" type=text value="{#aaaa}"style="display:none">'

                  aaaa=  aaaa.replace("{#aaaa}",aaa[i].id)
                    $(".dizhiTop").append(aaaa)

                }

            }
        }
    })
}

function gouwuche() {
    var url = "/goldPig/cart/showCart"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "dataType": "json",
        "success": function (json) {
            console.log(json)
            maxPage = json.retData.listData;



            for (var i = 0; i < maxPage.length; i++) {
                var html =
                    '<div class="cartsItem">'
                    + '<input class="storeBtn" type="checkbox" id="item#{cartid}" value="2" onchange="xuanzhong(#{price},#{cartid})">'
                    + '<div class="CartDelete"onClick="delcart(#{cartid})">删除</div>'
                    + '<div class="cartsItemCenter">'
                    + '<img class="goodsImg" src="../#{goodsimg}">'
                    + '<div class="cartItemCright">'
                    + '<div class="goodsName">#{goodsname}</div>'
                    + '<div class="goodsConfig"></div>'
                    + '<div class="goodsPrice">￥#{price}</div>'
                    + '<div class="goodsNum">'
                    + '<input type="button" value="-" class="goodsNumjian" id="jian#{cartid}" onclick="jian(#{cartid},#{price},#{shangpinId})">'
                    + '<input type="text" class="shuliang" id="aa#{cartid}" value={#count} >'
                    + '<input type="button" value="+" class="goodsNumjia" id="jia#{cartid}"onclick="jia(#{cartid},#{price},#{shangpinId})"></div>'
                    + '</div>'
                    + '</div>'
                    + '</div>'
                    + '</div>'
                var reg = new RegExp("#{price}", "g");
                var gouwuid = new RegExp("#{cartid}", "g");
                var goodsaaa = new RegExp("#{shangpinId}", "g");
                html = html.replace(gouwuid, String(maxPage[i].cartId));
                html = html.replace("#{goodsimg}", String(maxPage[i].goodsImg));
                html = html.replace("{#count}", String(maxPage[i].count));

                html = html.replace("#{goodsname}", String(maxPage[i].goodsName));
                
                html = html.replace(goodsaaa, String(maxPage[i].goodsId));
                html = html.replace(reg, maxPage[i].price);


                $("#cartCenter").append(html);

                $("#item"+maxPage[i].cartId).click()
            }
            var kong =
                '<div id="some" ></div>'
            $("#cartCenter").append(kong);

        }
    })

}



var zongcart = new Array();


function xuanzhong(aaa, id) {
    var price = toMoney(aaa)  //单价
    var zongjia = toMoney($("#CBCprice").html())  //总价
    var thisNum = toMoney($("#aa" + id).val())        //数量



    var thisMoney = toMoney(thisNum * price)          //这一条价格

    var istrue = $("#item" + id).prop("checked")
    console.log(istrue)
    if (istrue == true) {
        var endNum = parseFloat(zongjia) + parseFloat(thisMoney)
        $("#CBCprice").html(toMoney(endNum))
        zongcart.push([id])

    }
    if (!istrue == true) {
        var endNum = parseFloat(zongjia) - parseFloat(thisMoney)
        console.log(endNum)
        $("#CBCprice").html(toMoney(endNum))
        zongcart.pop()

    }
}


function jia(aa, price, goods) {
    var dangqian = Number($("#aa" + aa).val())
    var zongjia = toMoney($("#CBCprice").html())
    dangqian = dangqian + 1
    $("#aa" + aa).val(dangqian)
    if ($("#item" + aa).prop("checked") == true) {
        $("#CBCprice").html(toMoney(parseFloat(zongjia) + price))

    }
    addCart(goods, 1)
}
function jian(bb, price, goods) {
    var dangqian = Number($("#aa" + bb).val())
    var zongjia = toMoney($("#CBCprice").html())
    if (dangqian > 0) {
        dangqian = dangqian - 1
    }

    $("#aa" + bb).val(dangqian)
    if ($("#item" + bb).prop("checked") == true) {
        $("#CBCprice").html(toMoney(parseFloat(zongjia) - price))
    }
    addCart(goods, -1)

}


function addCart(path, num) {
    console.log(path + num)
    var url = "/goldPig/cart/addToCart"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "goodsId=" + path + "&goodsNum=" + num,
        "dataType": "json",
        "success": function (json) {
            console.log(json)

        }

    })
}

function delcart(id) {
    var url = "/goldPig/cart/cartDel"
    $.ajax({
        
        
        "url": ajaxUrl + url,
        "type": "post",
        "data": "cartId=" + id,
         "dataType": "json",
        "success": function (json) {
            location.reload()
        }
    })
    // location.reload() 
}

function cartPay(zongcart, money) {
    var dizhiid=$("#dizhiid").val()
    if(dizhiid==null||""){
        alert("请先填写收货地址")
        location.href="addSite.html"
    }
    console.log(dizhiid)
    var cartid = ""
    for (var i = 0; i < zongcart.length; i++) {
        cartid = cartid + zongcart[i]
    }
    var aaa = cartid + money
    console.log(aaa)
    var url = "/goldPig/order/createOrderByCart"
    $.ajax({
        "xhrFields": {
            withCredentials: true
        },
        "url": ajaxUrl + url,
        "type": "post",
        "data": "cartIds=" + zongcart + "&discount=" + 0 + "&money=" + money + "&encodeStr=" + aaa,
        "dataType": "json",
        "success": function (json) {

            console.log(json)
            var _appId = json.retData.appId
            var _nonceStr = json.retData.nonceStr
            var _prepayid = json.retData.package
            var prepayId=_prepayid.substring(10)
            var _paySign = json.retData.paySign
            var _timestamp = json.retData.timeStamp;

            wx.config({
                appId: _appId, // 必填，公众号的唯一标识
                timestamp: "" + _timestamp, // 必填，生成签名的时间戳
                nonceStr: _nonceStr, // 必填，生成签名的随机串
                signType: "MD5",
                paySign: _paySign,// 必填，签名
                jsApiList: ['chooseWXPay', 'requestPayment'] // 必填，需要使用的JS接口列表

            });
            wx.ready(function () {
               // location.href="userCoupon.html"
            parent.wx.miniProgram.redirectTo({ url: '/pages/WXpay/WXpay?'+"aaaa="+_appId+"&bbbb="+_timestamp+"&cccc="+_nonceStr+"&dddd="+prepayId+"&eeee="+_paySign});
            });
            wx.error(function () {
               
            });



        }
    })
}


